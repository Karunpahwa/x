# ProcureAI UI Helper MCP Tool

## Setup

1. Add your OpenAI key in `mcp.json`:
   ```json
   "OPENAI_API_KEY": "sk-..."
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Run the tool:
   ```bash
   node mcp-ui-helper.js
   ```

4. Open Cursor, go to Settings > MCP Servers. It should show `ui-helper-ai`.

5. Highlight a task from `ui-component-tasks.md`, right-click → Run tool → `expandUiTask`.
