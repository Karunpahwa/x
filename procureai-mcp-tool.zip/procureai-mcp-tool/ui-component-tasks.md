# UI Component Tasks for ProcureAI

## 1. Requirement Input Form

- [ ] Create `RequirementForm.tsx` component
  - [ ] Use `shadcn/ui` form elements and validation messages
  - [ ] Integrate `React Hook Form` with `Zod` schema for input validation
  - [ ] Include fields: title, description, budget range, urgency level
  - [ ] Add rich text editor for enhanced specification entry
- [ ] Add auto-save logic and character limit indicators
- [ ] Hook up submit to backend API `/api/requirements`
- [ ] Acceptance Criteria:
  - All mandatory fields enforced
  - Inputs are type-validated using Zod
  - Error messages appear clearly
  - Form autosaves after each keystroke

## 2. Vendor Match Results Card

- [ ] Create `VendorCard.tsx`
  - [ ] Display: company name, rating, capabilities, relevance score
  - [ ] Add "Select for Invite" toggle
  - [ ] Use Tailwind utility classes for spacing, layout, and color
- [ ] Add filtering by rating, location, or category
- [ ] Acceptance Criteria:
  - Cards adapt responsively (mobile/desktop)
  - Match score visual indicator (0–100)
  - User can select/deselect vendors for negotiation
